<html>
<head>
    <meta charset="utf-8">
</head>

<body>
 
</body>

<form action="check.php" method="GET">
    <b><font size="5">高大資管論文投稿系統</font></b>
    <p></p>
    請選擇您的角色：
    <select name="sRole">
        <option value="Chair">Chair
        <option value="Reviewer" >Reviewer
        <option value="Author">Author
    </select><br/>
    帳號：<input type="text" name="uName"><br/>
    密碼：<input type="password" name="uPSW"><br/>

    <input type="submit" value="提交">
</form>

</html>
